package test;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import com.relevantcodes.extentreports.LogStatus;

public class AmazonTest {
	WebDriver driver;
	File f;
	String regUrl;
	String logUrl;
	String homeUrl;
	String driverPath;
	SoftAssert sa;
	BufferedReader fr;
	ExtentReports report;
	ExtentTest test;
	
	
	@Test( priority = 1 )
	public void negative() throws InterruptedException, IOException {
		driver.get(regUrl);
		test = report.startTest("Negative Test");
		test.log(LogStatus.INFO, "Register Started. Expected: Register Successfully");
		String[] data1 = fr.readLine().split(" ");
		driver.findElement(By.xpath("//input[@id='ap_customer_name']")).sendKeys(data1[0]);
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(data1[1]);
		driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys(data1[2]);
		driver.findElement(By.xpath("//input[@id='ap_password_check']")).sendKeys(data1[3]);
		driver.findElements(By.className("a-button-input")).get(0).click();
		Thread.sleep(1000);
		int count = 0;
		regReport(count);
		Thread.sleep(1000);
	}
	
	@Test( priority = 2 )
	public void positive() throws InterruptedException, IOException {
		test = report.startTest("Positive Test");
		test.log(LogStatus.INFO, "Register Started. Expected: Register Successfully");
		driver.get(regUrl);
		String[] data2 = fr.readLine().split(" ");
		driver.findElement(By.xpath("//input[@id='ap_customer_name']")).sendKeys(data2[0]);
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(data2[1]);
		driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys(data2[2]);
		driver.findElement(By.xpath("//input[@id='ap_password_check']")).sendKeys(data2[3]);
		driver.findElements(By.className("a-button-input")).get(0).click();
		Thread.sleep(1000);
		int count = 0;
		regReport(count);
		Thread.sleep(1000);
	}
	
	@Test( priority = 3 )
	public void neglogin() throws IOException, InterruptedException {
		test = report.startTest("Negative Login");
		test.log(LogStatus.INFO, "Login Started. Expected: Login Successfully");
		driver.get(logUrl);
		String[] data3 = fr.readLine().split(" ");
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(data3[0]);
		driver.findElement(By.xpath("//input[@id='continue']")).click();
		Thread.sleep(1000);
		if(driver.findElements(By.className("a-alert-heading")).get(0).getText().length() >= 1) {
			test.log(LogStatus.FAIL, "Email Address Is Not Valid");
		}
		else {
			test.log(LogStatus.PASS, "Email Address Passed");
		}
		test.log(LogStatus.INFO, "Actual: Login Failed");
		Thread.sleep(1000);
	}
	
	@Test( priority = 4 )
	public void poslogin() throws IOException, InterruptedException {
		test = report.startTest("Positive Login");
		test.log(LogStatus.INFO, "Login Started. Expected: Login Successfully");
		driver.get(logUrl);
		String[] data4 = fr.readLine().split(" ");
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(data4[0]);
		driver.findElement(By.xpath("//input[@id='continue']")).click();
		if(driver.findElements(By.className("a-alert-heading")).get(0).getText().length() >= 1) {
			test.log(LogStatus.FAIL, "Email Address Is Not Valid");
		}
		else {
			test.log(LogStatus.PASS, "Email Address Passed");
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys(data4[1]);
		driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
		Thread.sleep(1000);
		test.log(LogStatus.INFO, "Actual: Login Passed");
		Thread.sleep(1000);
	}
	
	@Test( priority = 5)
	public void purchaseItems() throws IOException, InterruptedException{
		driver.get(homeUrl);
		test = report.startTest("Add Items");
		String title = driver.getTitle();
		test.log(LogStatus.INFO, "Add Items Started. Expected: Add Items Successfully");
		String data5 = fr.readLine();
		WebElement searchBox=driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
        searchBox.clear();
        searchBox.sendKeys(data5);
        driver.findElement(By.className("nav-input")).click();
        Thread.sleep(1000);

        driver.findElements(By.cssSelector(".a-link-normal.a-text-normal")).get(3).click();
  
        driver.findElement(By.id("add-to-cart-button")).click();
        Thread.sleep(1000);
        if(driver.findElement(By.id("nav-cart-count")).getText().equals("1")) {
        	test.log(LogStatus.PASS, "Add Items To Cart Passed");
        }else {
        	test.log(LogStatus.FAIL, "Add Items To Cart FAILED");
        }
        List<WebElement> listOfElements = driver.findElements(By.className("a-button-input"));
        listOfElements.get(1).click();
        driver.findElement(By.xpath("//input[@id='smartShelfAddToCartNative']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='proceedToRetailCheckout']")).click();
        if(!driver.getTitle().equals(title)) {
        	test.log(LogStatus.PASS, "Check Out Passed");
        }
        else {
        	test.log(LogStatus.FAIL, "Check Out Passed");
        }
        test.log(LogStatus.INFO, "Actual: Add Items Successfully");
        Thread.sleep(1000);
	}
  
	@BeforeTest
	public void beforeTest() throws IOException {
		f = new File("src/TestData.txt");
		fr = new BufferedReader(new FileReader(f)); 
		report = new ExtentReports(
				"SeleniumAmazonTest.html", true);
		driverPath = fr.readLine();
		regUrl = fr.readLine();
		logUrl = fr.readLine();
		homeUrl = fr.readLine();
		System.setProperty("webdriver.chrome.driver",
			  driverPath);
		driver  = new ChromeDriver();
	}

	@AfterTest
	public void afterTest() {
		report.endTest(test);
		report.flush();
		driver.quit();
	}
	
	public void regReport(int count) {
		if(driver.findElements(By.className("a-alert-content")).get(1).getText().length()>=1) {
			test.log(LogStatus.FAIL, "Name Cannot Be Empty");
			count++;
		}
		else {
			test.log(LogStatus.PASS, "Name Passed");
		}
		if(driver.findElements(By.className("a-alert-content")).get(3).getText().length()>=1) {
			test.log(LogStatus.FAIL, "Email Address Is Not Valid");
			count++;
		}
		else {
			test.log(LogStatus.PASS, "Email Address Passed");
		}
		if(driver.findElements(By.className("a-alert-content")).get(9).getText().length()>=1) {
			test.log(LogStatus.FAIL, "Password Format Is Not Valid");
			count++;
		}
		else {
			test.log(LogStatus.PASS, "Password Passed");
		}
		if(driver.findElements(By.className("a-alert-content")).get(11).getText().length()>=1) {
			test.log(LogStatus.FAIL, "Password Check Doesn't Match");
			count++;
		}
		else {
			test.log(LogStatus.PASS, "Password Check Passed");
		}
		if(count > 0) {
			test.log(LogStatus.ERROR, "Negative Case Doesn't Pass");
			test.log(LogStatus.INFO, (count + " Information Is Not Valid"));
			test.log(LogStatus.INFO, "Actual: Register Failed");
		}else {
			test.log(LogStatus.PASS, "Positive Case Passed");
			test.log(LogStatus.INFO, (count + " Information Is Not Valid"));
			test.log(LogStatus.INFO, "Actual: Register Successfuly");
		}
	}
}
